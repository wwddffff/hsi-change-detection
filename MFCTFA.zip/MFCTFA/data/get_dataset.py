# data/get_dataset.py
# -*- coding: utf-8 -*-

import os
from scipy.io import loadmat

# 你的所有数据集所在目录
DATA_ROOT = "/root/autodl-tmp/AIWSEN/HyperspectralChangeDetectionData"


def _load_dataset(mat_name,
                  key_before="T1",
                  key_after="T2",
                  key_gt="GT"):
    """
    通用加载函数，假定 .mat 内键名为 T1/T2/GT
    如果某个数据集键名不一样（比如 Binary），这里单独改即可。
    """
    mat_path = os.path.join(DATA_ROOT, mat_name)
    if not os.path.exists(mat_path):
        raise FileNotFoundError(f"{mat_path} 不存在，请检查路径")

    data = loadmat(mat_path)

    if key_before not in data or key_after not in data or key_gt not in data:
        raise KeyError(
            f"{mat_path} 中至少要包含 {key_before}/{key_after}/{key_gt}，"
            f"实际键：{list(data.keys())}"
        )

    img1 = data[key_before].astype("float32")
    img2 = data[key_after].astype("float32")
    gt = data[key_gt].astype("float32")

    return img1, img2, gt


def get_dataset(current_dataset):
    """
    根据 configs.current_dataset 选择对应的数据集。
    目前支持：Farmland / Hermiston / River
    如果以后加新数据集，在这里再加一个 elif 分支即可。
    """
    if current_dataset == "Farmland":
        return _load_dataset("Farmland.mat")

    elif current_dataset == "Hermiston":
        return _load_dataset("Hermiston.mat")

    elif current_dataset == "River":
        return _load_dataset("River.mat")
    

    else:
        raise ValueError(f"未知数据集: {current_dataset}")
