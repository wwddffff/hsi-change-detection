# -*- coding: utf-8 -*-
import copy
import math
import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from timm.layers import trunc_normal_
from model.dct import MultiSpectralAttentionLayer

def _pick_heads(dim: int, prefer=(8, 7, 6, 5, 9, 11, 4, 3, 2, 1)):
    for h in prefer:
        if dim % h == 0:
            return h
    return 1


# =========================================================
# Haar DWT / IDWT
# =========================================================
def haar_dwt2(x):
    B, C, H, W = x.shape
    pad_h = H % 2
    pad_w = W % 2
    if pad_h or pad_w:
        x = F.pad(x, (0, pad_w, 0, pad_h), mode='reflect')

    x00 = x[:, :, 0::2, 0::2]
    x01 = x[:, :, 0::2, 1::2]
    x10 = x[:, :, 1::2, 0::2]
    x11 = x[:, :, 1::2, 1::2]

    ll = (x00 + x01 + x10 + x11) * 0.5
    lh = (x00 - x01 + x10 - x11) * 0.5
    hl = (x00 + x01 - x10 - x11) * 0.5
    hh = (x00 - x01 - x10 + x11) * 0.5
    return ll, lh, hl, hh


def haar_idwt2(ll, lh, hl, hh):
    x00 = ll + lh + hl + hh
    x01 = ll - lh + hl - hh
    x10 = ll + lh - hl - hh
    x11 = ll - lh - hl + hh

    B, C, H2, W2 = ll.shape
    y = torch.empty((B, C, H2 * 2, W2 * 2), device=ll.device, dtype=ll.dtype)
    y[:, :, 0::2, 0::2] = x00 * 0.5
    y[:, :, 0::2, 1::2] = x01 * 0.5
    y[:, :, 1::2, 0::2] = x10 * 0.5
    y[:, :, 1::2, 1::2] = x11 * 0.5
    return y


# =========================================================
# Basic Layers
# =========================================================
class LayerNorm2d(nn.Module):
    def __init__(self, num_channels: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(num_channels))
        self.bias = nn.Parameter(torch.zeros(num_channels))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        u = x.mean(1, keepdim=True)
        s = (x - u).pow(2).mean(1, keepdim=True)
        x = (x - u) / torch.sqrt(s + self.eps)
        x = self.weight[:, None, None] * x + self.bias[:, None, None]
        return x


class EnhancerBlock(nn.Module):
    def __init__(self, dim, kernel_size=3, mlp_ratio=2.0):
        super().__init__()
        self.dwconv = nn.Conv2d(
            dim, dim, kernel_size=kernel_size,
            padding=kernel_size // 2, groups=dim
        )
        self.norm = LayerNorm2d(dim)
        hidden_dim = int(dim * mlp_ratio)
        self.pwconv1 = nn.Conv2d(dim, hidden_dim, 1)
        self.act = nn.GELU()
        self.pwconv2 = nn.Conv2d(hidden_dim, dim, 1)

    def forward(self, x):
        shortcut = x
        x = self.dwconv(x)
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)
        return shortcut + x


class HighFreqEnhancer(nn.Module):
    def __init__(self, in_features, hidden_features=None, kernel_size=3):
        super().__init__()
        hidden_features = hidden_features or in_features
        self.proj_in = nn.Conv2d(in_features, hidden_features, 1)
        self.block = EnhancerBlock(hidden_features, kernel_size=kernel_size)
        self.proj_out = nn.Conv2d(hidden_features, in_features, 1)

    def forward(self, x):
        x = self.proj_in(x)
        x = self.block(x)
        x = self.proj_out(x)
        return x


def _build_sine_pe(length, dim, device):
    pe = torch.zeros(length, dim, device=device)
    position = torch.arange(0, length, dtype=torch.float, device=device).unsqueeze(1)
    div_term = torch.exp(
        torch.arange(0, dim, 2, dtype=torch.float, device=device)
        * -(math.log(10000.0) / dim)
    )
    pe[:, 0::2] = torch.sin(position * div_term)
    if dim % 2 == 1:
        pe[:, 1::2] = torch.cos(position * div_term)[:, :-1]
    else:
        pe[:, 1::2] = torch.cos(position * div_term)
    return pe.unsqueeze(0)


# =========================================================
# Focused Linear Attention
# =========================================================
class FocusedLinearAttention(nn.Module):
    def __init__(
        self,
        dim,
        num_patches,
        num_heads=5,
        qkv_bias=False,
        qk_scale=None,
        attn_drop=0.,
        proj_drop=0.,
        sr_ratio=1,
        focusing_factor=3,
        kernel_size=5
    ):
        super().__init__()
        if dim % num_heads != 0:
            new_heads = _pick_heads(dim)
            warnings.warn(
                f"[FocusedLinearAttention] dim={dim} cannot be divided by "
                f"num_heads={num_heads}, changed to {new_heads}.",
                RuntimeWarning
            )
            num_heads = new_heads

        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads

        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.sr_ratio = sr_ratio
        if sr_ratio > 1:
            self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)
            self.norm = nn.LayerNorm(dim)

        self.focusing_factor = focusing_factor
        self.dwc = nn.Conv2d(
            head_dim, head_dim, kernel_size=kernel_size,
            groups=head_dim, padding=kernel_size // 2
        )
        self.scale = nn.Parameter(torch.zeros(1, 1, dim))
        self.positional_encoding = None

    def _get_positional_encoding(self, needed_len: int, device):
        if (
            self.positional_encoding is None
            or self.positional_encoding.shape[1] != needed_len
            or self.positional_encoding.device != device
        ):
            self.positional_encoding = _build_sine_pe(needed_len, self.dim, device)
        return self.positional_encoding

    def forward(self, x1, x2, H, W):
        B, N, C = x1.shape

        q = self.q(x2)
        if self.sr_ratio > 1:
            x_ = x1.permute(0, 2, 1).reshape(B, C, H, W)
            x_ = self.sr(x_).reshape(B, C, -1).permute(0, 2, 1)
            x_ = self.norm(x_)
            kv = self.kv(x_).reshape(B, -1, 2, C).permute(2, 0, 1, 3)
        else:
            kv = self.kv(x1).reshape(B, -1, 2, C).permute(2, 0, 1, 3)

        k, v = kv[0], kv[1]

        Nk = k.shape[1]
        pos_encoding = self._get_positional_encoding(Nk, k.device)
        k = k + pos_encoding

        scale = F.softplus(self.scale) + 1e-6

        q = F.relu(q) + 1e-6
        k = F.relu(k) + 1e-6
        q = q / scale
        k = k / scale

        q_norm = q.norm(dim=-1, keepdim=True)
        k_norm = k.norm(dim=-1, keepdim=True)

        q = q.pow(self.focusing_factor)
        k = k.pow(self.focusing_factor)

        q = (q / (q.norm(dim=-1, keepdim=True) + 1e-6)) * q_norm
        k = (k / (k.norm(dim=-1, keepdim=True) + 1e-6)) * k_norm

        q, k, v = (
            rearrange(t, "b n (h c) -> (b h) n c", h=self.num_heads)
            for t in (q, k, v)
        )

        i, j, c_dim, d_dim = q.shape[-2], k.shape[-2], k.shape[-1], v.shape[-1]
        z = 1.0 / (torch.einsum("b i c, b c -> b i", q, k.sum(dim=1)) + 1e-6)

        if i * j * (c_dim + d_dim) > c_dim * d_dim * (i + j):
            kv_prod = torch.einsum("b j c, b j d -> b c d", k, v)
            x = torch.einsum("b i c, b c d, b i -> b i d", q, kv_prod, z)
        else:
            qk_prod = torch.einsum("b i c, b j c -> b i j", q, k)
            x = torch.einsum("b i j, b j d, b i -> b i d", qk_prod, v, z)

        if self.sr_ratio > 1:
            v_for_map = F.interpolate(
                v.permute(0, 2, 1),
                size=x.shape[1],
                mode='linear',
                align_corners=False
            ).permute(0, 2, 1)
        else:
            v_for_map = v

        feature_map = rearrange(v_for_map, "b (h w) c -> b c h w", h=H, w=W)
        feature_map = rearrange(self.dwc(feature_map), "b c h w -> b (h w) c")
        x = x + feature_map

        x = rearrange(x, "(b h) n c -> b n (h c)", h=self.num_heads)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None,
                 attn_drop=0., proj_drop=0., qk_ratio=1, sr_ratio=1):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5
        self.qk_dim = dim // qk_ratio

        self.q = nn.Linear(dim, self.qk_dim, bias=qkv_bias)
        self.k = nn.Linear(dim, self.qk_dim, bias=qkv_bias)
        self.v = nn.Linear(dim, dim, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.sr_ratio = sr_ratio
        if self.sr_ratio > 1:
            self.sr = nn.Sequential(
                nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio, groups=dim, bias=True),
                nn.BatchNorm2d(dim, eps=1e-5),
            )

    def forward(self, x, H, W, relative_pos):
        B, N, C = x.shape
        q = self.q(x).reshape(B, N, self.num_heads, self.qk_dim // self.num_heads).permute(0, 2, 1, 3)

        if self.sr_ratio > 1:
            x_ = x.permute(0, 2, 1).reshape(B, C, H, W)
            x_ = self.sr(x_).reshape(B, C, -1).permute(0, 2, 1)
            k = self.k(x_).reshape(B, -1, self.num_heads, self.qk_dim // self.num_heads).permute(0, 2, 1, 3)
            v = self.v(x_).reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        else:
            k = self.k(x).reshape(B, N, self.num_heads, self.qk_dim // self.num_heads).permute(0, 2, 1, 3)
            v = self.v(x).reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        attn = (q @ k.transpose(-2, -1)) * self.scale + relative_pos
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class SpecBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None, groups=1,
                 base_width=64, dilation=1, norm_layer=None,
                 *, reduction=16, ):
        global _mapper_x, _mapper_y
        super(SpecBlock, self).__init__()
        c2wh = dict([(64,56), (128,28), (256,14) ,(512,7)])
        self.planes = planes
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.att = MultiSpectralAttentionLayer(planes, c2wh[planes], c2wh[planes],  reduction=reduction, freq_sel_method = 'top16')
        self.downsample = downsample
        self.stride = stride

        self.conv_s1 = nn.Conv2d(inplanes, planes, kernel_size=5, stride=stride, padding=2, bias=False)
        self.conv_s2 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.conv_s3 = nn.Conv2d(inplanes, planes, kernel_size=1, stride=stride, padding=0, bias=False)
        self.bn_s1 = nn.BatchNorm2d(planes)
        self.bn_s2 = nn.BatchNorm2d(planes)
        self.bn_s3 = nn.BatchNorm2d(planes)

        self.conv_mix1 = nn.Conv2d(planes * 2, planes, kernel_size=3, padding=1, bias=False)
        self.conv_mixRes = nn.Conv2d(planes * 2, planes, kernel_size=1, padding=0, bias=False)
        self.conv_mix2 = nn.Conv2d(planes, planes, kernel_size=3, padding=1, bias=False)
        self.bn_mix = nn.BatchNorm2d(planes)
        # self.relu_mix = nn.ReLU(inplace=True)

        self.bn3 = nn.BatchNorm2d(planes)

    @staticmethod
    def channel_shuffle(x, groups):

        b, c, h, w = x.shape
        x = x.reshape(b, groups, -1, h, w)  # 按照 groups 将通道维度进行重塑
        x = x.permute(0, 2, 1, 3, 4)  # 调整维度顺序，使通道组进行交换

        # 展平通道维度后返回
        x = x.reshape(b, -1, h, w)
        return x

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        out = self.att(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out1 = self.conv_s1(x)
        out1 = self.bn_s1(out1)
        out2 = self.conv_s2(x)
        out2 = self.bn_s2(out2)
        out3 = self.conv_s3(x)
        out3 = self.bn_s3(out3)
        out_sp = out1 + out2 + out3

        out_mix = torch.cat([out, out_sp], dim=1)
        out_mixRes = self.conv_mixRes(out_mix)
        out_mix = self.conv_mix1(out_mix)
        out_mix = self.bn_mix(out_mix)
        out_mix = self.relu(out_mix)
        out_mix = self.conv_mix2(out_mix)
        out_mix = out_mix + out_mixRes

        out_mix = self.bn3(out_mix)
        out_mix = self.relu(out_mix)

        # out_mix = self.channel_shuffle(out_mix, 4)

        return out_mix
# =========================================================
# Other Utils
# =========================================================
class GroupNorm(nn.GroupNorm):
    def __init__(self, num_channels, **kwargs):
        super().__init__(1, num_channels, **kwargs)


# =========================================================
# AIWSEN w/o FECAM + LSTM
# =========================================================
class AIWSEN(nn.Module):
    def __init__(
        self,
        layers=None,
        img_size=(5, 5),
        in_chans=155,
        embed_dims=None,
        mlp_ratios=None,
        downsamples=None,
        pool_size=3,
        norm_layer=GroupNorm,
        act_layer=nn.GELU,
        num_classes=2,
        in_patch_size=5,
        in_stride=4,
        in_pad=2,
        down_patch_size=3,
        down_stride=2,
        down_pad=1,
        drop_rate=0.,
        drop_path_rate=0.,
        use_layer_scale=True,
        layer_scale_init_value=1e-6,
        fork_feat=False,
        init_cfg=None,
        pretrained=None,
        qkv_bias=False,
        qk_scale=None,
        num_stages=2,
        fla_use_frl=True,
        fla_num_heads=None,
        fla_focusing_factor=3,
        return_logits=True,

        # 新增：QA 自注意力模块的参数
        qa_num_heads=None,
        qa_sr_ratio=1,
        qa_qk_ratio=1,
        qa_attn_drop=0.,

        **kwargs
    ):
        super().__init__()

        # 原接口中的部分参数保留用于兼容旧调用，
        # 当前结构没有使用多阶段骨干、小波分支或 LSTM。
        if fork_feat:
            raise ValueError(
                "当前 AIWSEN 仅实现分类输出，不支持 fork_feat=True。"
            )

        if pretrained is not None or init_cfg is not None:
            raise ValueError(
                "当前类未实现 pretrained/init_cfg 权重加载，"
                "请创建模型后使用 load_state_dict() 加载权重。"
            )

        if not isinstance(in_chans, int) or in_chans <= 0:
            raise ValueError("in_chans 必须是正整数。")

        if not isinstance(num_classes, int) or num_classes <= 0:
            raise ValueError("num_classes 必须是正整数。")

        if not isinstance(qa_sr_ratio, int) or qa_sr_ratio < 1:
            raise ValueError("qa_sr_ratio 必须是正整数。")

        if not isinstance(qa_qk_ratio, int) or qa_qk_ratio < 1:
            raise ValueError("qa_qk_ratio 必须是正整数。")

        if isinstance(img_size, int):
            img_size = (img_size, img_size)

        if len(img_size) != 2 or min(img_size) <= 0:
            raise ValueError("img_size 应为正整数或 (H, W)。")

        self.in_chans = in_chans
        self.num_classes = num_classes
        self.return_logits = return_logits
        self.embed_dims = (
            list(embed_dims)
            if embed_dims is not None
            else [96, 192, 384, 768]
        )
        self.fork_feat = False
        self.init_cfg = None

        # -------------------------------------------------
        # 1. FLA 头数：需要整除 in_chans
        # -------------------------------------------------
        if fla_num_heads is None:
            fla_heads = _pick_heads(in_chans)
        else:
            if not isinstance(fla_num_heads, int) or fla_num_heads <= 0:
                raise ValueError("fla_num_heads 必须是正整数。")

            if in_chans % fla_num_heads != 0:
                fla_heads = _pick_heads(in_chans)
                warnings.warn(
                    f"[AIWSEN] in_chans={in_chans} 不能被 "
                    f"fla_num_heads={fla_num_heads} 整除，"
                    f"已调整为 {fla_heads}。",
                    RuntimeWarning
                )
            else:
                fla_heads = fla_num_heads

        # -------------------------------------------------
        # 2. QA 头数：同时整除 V 维度和 Q/K 维度
        # -------------------------------------------------
        qk_dim = in_chans // qa_qk_ratio

        if qk_dim < 1:
            raise ValueError(
                "qa_qk_ratio 过大，导致 Q/K 通道数小于 1。"
            )

        if qa_num_heads is None:
            # 公约数的因子同时整除 in_chans 和 qk_dim
            qa_heads = _pick_heads(math.gcd(in_chans, qk_dim))
        else:
            if not isinstance(qa_num_heads, int) or qa_num_heads <= 0:
                raise ValueError("qa_num_heads 必须是正整数。")

            if (
                in_chans % qa_num_heads != 0
                or qk_dim % qa_num_heads != 0
            ):
                raise ValueError(
                    f"qa_num_heads={qa_num_heads} 必须同时整除 "
                    f"in_chans={in_chans} 和 qk_dim={qk_dim}。"
                )

            qa_heads = qa_num_heads

        # -------------------------------------------------
        # 3. 共享自注意力
        # qa_sr_ratio > 1 时启用 DWConv + BN 下采样
        # -------------------------------------------------
        self.QA = Attention(
            dim=in_chans,
            num_heads=qa_heads,
            qkv_bias=qkv_bias,
            qk_scale=qk_scale,
            attn_drop=qa_attn_drop,
            proj_drop=drop_rate,
            qk_ratio=qa_qk_ratio,
            sr_ratio=qa_sr_ratio
        )

        # -------------------------------------------------
        # 4. 共享交叉注意力
        # FLA(x1, x2): K/V 来自 x1，Q 来自 x2
        # -------------------------------------------------
        self.FLA = FocusedLinearAttention(
            dim=in_chans,
            num_patches=img_size[0] * img_size[1],
            num_heads=fla_heads,
            qkv_bias=qkv_bias,
            qk_scale=qk_scale,
            attn_drop=0.,
            proj_drop=drop_rate,
            sr_ratio=1,
            focusing_factor=fla_focusing_factor,
            kernel_size=5
        )

        # -------------------------------------------------
        # 5. 两路差分拼接：[B, 2C, H, W] → [B, 64, H, W]
        # -------------------------------------------------
        self.fuse_proj = nn.Sequential(
            nn.Conv2d(
                in_channels=3 * in_chans,
                out_channels=64,
                kernel_size=1,
                bias=False
            ),
            nn.BatchNorm2d(64),
            nn.GELU()
        )

        self.facBasic = SpecBlock(
            inplanes=64,
            planes=64
        )

        # -------------------------------------------------
        # 6. 全局池化与分类
        # -------------------------------------------------
        self.global_pool = nn.AdaptiveAvgPool2d(1)

        self.fc = nn.Sequential(
            nn.Dropout(drop_rate),
            nn.Linear(64, num_classes)
        )

        self.apply(self.cls_init_weights)

    def cls_init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=0.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def get_classifier(self):
        return self.fc

    def reset_classifier(self, num_classes):
        if not isinstance(num_classes, int) or num_classes <= 0:
            raise ValueError("num_classes 必须是正整数。")

        old_layer = self.fc[-1]

        new_layer = nn.Linear(
            old_layer.in_features,
            num_classes,
            bias=True
        ).to(
            device=old_layer.weight.device,
            dtype=old_layer.weight.dtype
        )

        self.cls_init_weights(new_layer)
        new_layer.train(self.training)

        self.fc[-1] = new_layer
        self.num_classes = num_classes

    def forward(self, x1, x2):
        # -------------------------------------------------
        # 输入检查
        # -------------------------------------------------
        if x1.ndim != 4 or x2.ndim != 4:
            raise ValueError(
                "x1、x2 必须是 [B, C, H, W] 四维张量。"
            )

        if x1.shape != x2.shape:
            raise ValueError(
                f"两时相输入形状必须一致，实际为 "
                f"{tuple(x1.shape)} 和 {tuple(x2.shape)}。"
            )

        B, C, H, W = x1.shape

        if C != self.in_chans:
            raise ValueError(
                f"模型要求 {self.in_chans} 个通道，实际输入为 {C}。"
            )

        if H < self.QA.sr_ratio or W < self.QA.sr_ratio:
            raise ValueError(
                f"输入尺寸 {(H, W)} 不能小于 "
                f"qa_sr_ratio={self.QA.sr_ratio}。"
            )

        # -------------------------------------------------
        # 1. 特征图 → token 序列
        # [B, C, H, W] → [B, H*W, C]
        # -------------------------------------------------
        
                # 1. 特征图 → token 序列
        # [B, C, H, W] → [B, H*W, C]
        tokens1 = x1.flatten(2).transpose(1, 2)
        tokens2 = x2.flatten(2).transpose(1, 2)

        # 2. 第一层共享自注意力
        X1 = self.QA(tokens1, H, W, relative_pos=0)
        X2 = self.QA(tokens2, H, W, relative_pos=0)

        # 3. 第一层双向交叉注意力
        # FLA(a, b)：K/V 来自 a，Q 来自 b
        Cross1 = self.FLA(X1, X2, H, W)
        Cross11 = self.FLA(X2, X1, H, W)

        # 4. 第二层共享自注意力
        X11 = self.QA(X1, H, W, relative_pos=0)
        X22 = self.QA(X2, H, W, relative_pos=0)

        # 5. 第二层双向交叉注意力
        Cross2 = self.FLA(X11, X22, H, W)
        Cross22 = self.FLA(X22, X11, H, W)

        # 6. 三路有符号差分
        diff_self = (
            (X1 - X2)
            .transpose(1, 2)
            .reshape(B, C, H, W)
        )

        diff_cross = (
            (Cross11 - Cross1)
            .transpose(1, 2)
            .reshape(B, C, H, W)
        )

        diff_cross2 = (
            (Cross22 - Cross2)
            .transpose(1, 2)
            .reshape(B, C, H, W)
        )

        # 7. 三路拼接 → 通道投影 → SpecBlock
        fused_map = torch.cat(
            [diff_self, diff_cross, diff_cross2],
            dim=1
        )                                       # [B, 3C, H, W]

        fused_map = self.fuse_proj(fused_map)     # [B, 64, H, W]
        fused_map = self.facBasic(fused_map)      # [B, 64, H, W]

        # 8. 池化 → 分类
        fused_vec = self.global_pool(fused_map).flatten(1)
        logits = self.fc(fused_vec)

        if self.return_logits:
            return logits

        return F.softmax(logits, dim=1)