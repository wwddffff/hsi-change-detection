# -*- coding: utf-8 -*-
# run_batch.py
import os
import sys
from scipy.io import loadmat
import torch # 建议导入 torch 用于清理显存

# -------------- 路径配置 ----------------
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
# 你的数据集总目录
DATA_ROOT = "/root/autodl-tmp/AIWSEN/HyperspectralChangeDetectionData"

# 确保在项目根目录下运行
os.chdir(PROJECT_ROOT)
sys.path.append(PROJECT_ROOT) # 确保导包路径正确

import configs.configs as cfg
from train_HSI import main as train_main

def get_band_num(dataset_name: str) -> int:
    mat_path = os.path.join(DATA_ROOT, f"{dataset_name}.mat")
    if not os.path.exists(mat_path):
        raise FileNotFoundError(f"{mat_path} 不存在，请检查数据集文件名")

    data = loadmat(mat_path)
    if "T1" not in data:
        raise KeyError(f"{mat_path} 中找不到键 'T1'，实际键有：{list(data.keys())}")

    img1 = data["T1"]
    if img1.ndim != 3:
        raise ValueError(f"{mat_path} 中 T1 形状为 {img1.shape}，期望为 [H, W, C] 三维")

    return int(img1.shape[2])

def configure_for_run(dataset_name: str, run_idx: int):
    # === 1. 数据集名 ===
    cfg.current_dataset = dataset_name
    cfg.data["current_dataset"] = dataset_name

    # === 2. 通道数 ===
    in_fea_num = get_band_num(dataset_name)
    cfg.model["in_fea_num"] = in_fea_num

    # === 3. 权重保存设置 ===
    weights_dir = os.path.join(PROJECT_ROOT, "weights", dataset_name)
    os.makedirs(weights_dir, exist_ok=True)

    weight_name = f"{dataset_name}{run_idx}"

    cfg.train["train_model"]["save_folder"] = weights_dir
    cfg.train["train_model"]["save_name"] = weight_name
    cfg.train["train_model"]["reuse_model"] = False
    cfg.train["train_model"]["reuse_file"] = os.path.join(
        weights_dir, weight_name + "_Final.pth"
    )

    # === 4. 测试阶段用哪个权重 ===
    cfg.test["model_weights"] = os.path.join(
        weights_dir, weight_name + "_Final.pth"
    )

    # === 5. 结果保存 ===
    result_dir = os.path.join(PROJECT_ROOT, "result")
    os.makedirs(result_dir, exist_ok=True)
    cfg.test["save_folder"] = result_dir
    cfg.test["save_name"] = f"{dataset_name}{run_idx}"

def save_run_result_txt(dataset_name: str, run_idx: int):
    save_folder = cfg.test["save_folder"]
    save_name = cfg.test["save_name"]
    
    mat_path = os.path.join(save_folder, save_name + ".mat")
    if not os.path.exists(mat_path):
        print(f"[WARN] 找不到结果 mat 文件: {mat_path}，无法写入 txt。")
        return

    data = loadmat(mat_path)
    oa_arr = data.get("oa", None)

    summary = None
    if oa_arr is not None:
        summary = oa_arr.squeeze().tolist()

    txt_path = os.path.join(save_folder, save_name + "_result.txt")

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(f"dataset: {dataset_name}\n")
        f.write(f"run_idx: {run_idx}\n")
        if summary is not None and isinstance(summary, (list, tuple)):
            if len(summary) >= 6:
                oa, kappa, f1, P, R, model_name = summary[:6]
                f.write(f"OA(%): {oa}\n")
                f.write(f"Kappa: {kappa}\n")
                f.write(f"F1(%): {f1}\n")
                f.write(f"Precision(%): {P}\n")
                f.write(f"Recall(%): {R}\n")
                f.write(f"Model Name: {model_name}\n")
            else:
                f.write(f"oa(raw): {summary}\n")
        else:
            f.write("未在 mat 文件中找到 'oa'（assessment_result）字段。\n")
    
    print(f"[INFO] 本次运行结果写入: {txt_path}")

def main():
    datasets = ["Farmland", "Hermiston", "River"]   #"Farmland", "Hermiston", "River"

    for dataset_name in datasets:
        for run_idx in range(1, 11): 
            print("\n" + "=" * 80)
            print(f"开始运行数据集 {dataset_name}，第 {run_idx}/10 次")
            print("=" * 80 + "\n")
            
            try:
                # 配置本次运行
                configure_for_run(dataset_name, run_idx)
                
                # 运行主程序
                train_main()
                
                # 保存结果
                save_run_result_txt(dataset_name, run_idx)

                # === 关键：清理显存 ===
                # 因为是在同一个进程里循环，显存可能不会自动释放
                torch.cuda.empty_cache()
                
            except Exception as e:
                print(f"[ERROR] 运行 {dataset_name} 第 {run_idx} 次时发生错误: {e}")
                # 即使报错也继续跑下一个，防止整个实验中断
                continue

if __name__ == "__main__":
    main()